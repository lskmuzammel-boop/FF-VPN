package com.ffvpn.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import java.io.ByteArrayInputStream
import java.nio.charset.StandardCharsets

class FFVpnService : VpnService() {

    companion object {
        const val TAG = "FFVpnService"
        const val ACTION_CONNECT = "com.ffvpn.app.ACTION_CONNECT"
        const val ACTION_DISCONNECT = "com.ffvpn.app.ACTION_DISCONNECT"
        const val EXTRA_CONFIG = "EXTRA_CONFIG"
        const val EXTRA_TUNNEL_NAME = "EXTRA_TUNNEL_NAME"
        const val EXTRA_ENDPOINT = "EXTRA_ENDPOINT"
        const val NOTIFICATION_ID = 2026
        const val CHANNEL_ID = "ff_vpn_channel"

        var isConnected: Boolean = false
        var currentServerEndpoint: String = ""
        var currentTunnelName: String = "FF-VPN"
        var startTimeMs: Long = 0
    }

    private var backend: GoBackend? = null
    private var vpnInterface: ParcelFileDescriptor? = null

    private class FF敦Tunnel(private val name: String) : Tunnel {
        override fun getName(): String = name
        override fun onStateChange(newState: Tunnel.State) {
            Log.d(TAG, "Tunnel state changed: $newState")
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        backend = GoBackend(applicationContext)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: return START_NOT_STICKY

        when (action) {
            ACTION_CONNECT -> {
                val configText = intent.getStringExtra(EXTRA_CONFIG) ?: ""
                val tunnelName = intent.getStringExtra(EXTRA_TUNNEL_NAME) ?: "FF-VPN"
                val endpoint = intent.getStringExtra(EXTRA_ENDPOINT) ?: ""
                currentServerEndpoint = endpoint
                currentTunnelName = tunnelName
                startVpnTunnel(tunnelName, configText)
            }
            ACTION_DISCONNECT -> {
                stopVpnTunnel()
            }
        }

        return START_NOT_STICKY
    }

    private fun startVpnTunnel(tunnelName: String, configText: String) {
        try {
            startForeground(NOTIFICATION_ID, buildNotification("Connecting to $currentServerEndpoint..."))
            
            // Parse WireGuard config from standard .conf text
            val stream = ByteArrayInputStream(configText.toByteArray(StandardCharsets.UTF_8))
            val wgConfig = Config.parse(stream)

            val tunnel = FF敦Tunnel(tunnelName)
            backend?.setState(tunnel, Tunnel.State.UP, wgConfig)

            isConnected = true
            startTimeMs = System.currentTimeMillis()
            updateNotification("Connected to $currentServerEndpoint (Low Ping Gaming Active)")
            Log.i(TAG, "WireGuard Tunnel successfully established with $currentServerEndpoint")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start WireGuard tunnel: ${e.message}", e)
            isConnected = false
            stopSelf()
        }
    }

    private fun stopVpnTunnel() {
        try {
            val tunnel = FF敦Tunnel(currentTunnelName)
            backend?.setState(tunnel, Tunnel.State.DOWN, null)
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping tunnel: ${e.message}")
        } finally {
            vpnInterface?.close()
            vpnInterface = null
            isConnected = false
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    override fun onDestroy() {
        stopVpnTunnel()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "FF VPN Tunnel Status",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows active WireGuard connection status and gaming statistics"
                setShowBadge(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(statusText: String): Notification {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val disconnectIntent = Intent(this, FFVpnService::class.java).apply {
            action = ACTION_DISCONNECT
        }
        val disconnectPending = PendingIntent.getService(
            this,
            1,
            disconnectIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("FF VPN • WireGuard Gaming Active")
            .setContentText(statusText)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(pendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Disconnect", disconnectPending)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(statusText: String) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification(statusText))
    }
}
