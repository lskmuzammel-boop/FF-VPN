package com.ffvpn.app

import android.os.Bundle
import com.getcapacitor.BridgeActivity

class MainActivity : BridgeActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        // Register WireGuard Native Plugin
        registerPlugin(WireGuardVpnPlugin::class.java)
        super.onCreate(savedInstanceState)
    }
}
