import React from 'react';
import { Power, ShieldCheck, Loader2 } from 'lucide-react';
import { ConnectionState, Language } from '../types/vpn';
import { translations } from '../locales/translations';

interface ConnectButtonProps {
  state: ConnectionState;
  onToggle: () => void;
  lang: Language;
  durationSeconds: number;
}

export const ConnectButton: React.FC<ConnectButtonProps> = ({
  state,
  onToggle,
  lang,
  durationSeconds,
}) => {
  const t = translations[lang];

  const formatTimer = (secs: number) => {
    const hrs = Math.floor(secs / 3600);
    const mins = Math.floor((secs % 3600) / 60);
    const s = secs % 60;
    if (hrs > 0) {
      return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    }
    return `${mins.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const isConnected = state === 'CONNECTED';
  const isConnecting = state === 'CONNECTING' || state === 'DISCONNECTING';

  return (
    <div className="relative flex flex-col items-center justify-center my-6">
      {/* Outer Pulse Rings when Connected or Connecting */}
      {isConnected && (
        <>
          <div className="absolute w-64 h-64 rounded-full border border-emerald-500/20 animate-radar-ring pointer-events-none" />
          <div className="absolute w-76 h-76 rounded-full border border-emerald-400/10 animate-radar-ring [animation-delay:0.8s] pointer-events-none" />
        </>
      )}

      {/* Cyber Rotating Ring */}
      <div
        className={`w-56 h-56 rounded-full p-2 flex items-center justify-center transition-all duration-700 ${
          isConnected
            ? 'neon-glow-green bg-gradient-to-b from-emerald-500/20 via-black to-emerald-950/40'
            : isConnecting
            ? 'neon-glow-cyan bg-gradient-to-b from-cyan-500/20 via-black to-blue-950/40'
            : 'bg-gradient-to-b from-gray-800/40 via-black to-gray-900/60'
        }`}
      >
        {/* Outer Dial Track */}
        <div
          className={`w-full h-full rounded-full p-1.5 border border-dashed transition-all duration-700 flex items-center justify-center ${
            isConnected
              ? 'border-emerald-400/60 animate-spin-slow'
              : isConnecting
              ? 'border-cyan-400/80 animate-spin'
              : 'border-gray-700/60'
          }`}
        >
          {/* Inner Button Core */}
          <button
            onClick={onToggle}
            disabled={isConnecting}
            className={`w-44 h-44 rounded-full flex flex-col items-center justify-center relative cursor-pointer active:scale-95 transition-all duration-300 outline-none ${
              isConnected
                ? 'bg-gradient-to-br from-emerald-600 via-emerald-800 to-black text-white shadow-lg shadow-emerald-500/40 border-2 border-[#00FF66]'
                : isConnecting
                ? 'bg-gradient-to-br from-cyan-600 via-slate-900 to-black text-white shadow-lg shadow-cyan-500/30 border-2 border-cyan-400'
                : 'bg-gradient-to-br from-gray-900 via-black to-gray-950 text-gray-400 hover:text-white border-2 border-gray-700/70 hover:border-emerald-500/50 hover:shadow-lg hover:shadow-emerald-500/20'
            }`}
          >
            {/* Center Icon */}
            {isConnecting ? (
              <Loader2 className="w-14 h-14 text-cyan-300 animate-spin mb-1" />
            ) : isConnected ? (
              <ShieldCheck className="w-14 h-14 text-white drop-shadow-md mb-1" />
            ) : (
              <Power className="w-14 h-14 text-gray-300 group-hover:text-[#00FF66] transition-colors mb-1" />
            )}

            {/* Status Label Inside Button */}
            <span className="font-gaming font-extrabold tracking-widest text-xs uppercase px-2 text-center">
              {state === 'CONNECTED'
                ? t.disconnect
                : state === 'CONNECTING'
                ? t.connecting
                : state === 'DISCONNECTING'
                ? t.disconnecting
                : t.connect}
            </span>

            {/* Duration Display if Connected */}
            {isConnected && (
              <span className="mt-1 font-mono-code text-[11px] font-bold text-emerald-200 bg-emerald-950/70 px-2 py-0.5 rounded-full border border-emerald-400/30">
                {formatTimer(durationSeconds)}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Under-button Status Caption */}
      <div className="mt-4 flex flex-col items-center">
        <div className="flex items-center space-x-2">
          <span
            className={`w-2 h-2 rounded-full ${
              isConnected
                ? 'bg-[#00FF66] animate-ping'
                : isConnecting
                ? 'bg-cyan-400 animate-pulse'
                : 'bg-red-500'
            }`}
          />
          <span className="font-gaming font-bold text-xs uppercase tracking-wider text-gray-300">
            {isConnected ? t.connected : isConnecting ? t.connecting : t.disconnected}
          </span>
        </div>
        <p className="text-[11px] font-mono-code text-gray-500 mt-0.5">
          {t.protocol}
        </p>
      </div>
    </div>
  );
};
