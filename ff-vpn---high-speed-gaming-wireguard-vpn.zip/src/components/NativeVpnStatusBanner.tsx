import React, { useState } from 'react';
import { Smartphone, Info, ShieldCheck, FileText, Check, Copy } from 'lucide-react';
import { isNativeAndroid } from '../services/wireguardPlugin';
import { VpnServer } from '../types/vpn';
import { buildWireGuardConfig, formatWireGuardConfigFile } from '../services/wireguardConfig';

interface NativeVpnStatusBannerProps {
  activeServer: VpnServer;
}

export const NativeVpnStatusBanner: React.FC<NativeVpnStatusBannerProps> = ({ activeServer }) => {
  const [showConfig, setShowConfig] = useState(false);
  const [copied, setCopied] = useState(false);
  const isNative = isNativeAndroid();

  const configText = formatWireGuardConfigFile(buildWireGuardConfig(activeServer));

  const handleCopy = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(configText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="w-full px-4 mb-3">
      <div className="p-2.5 rounded-xl bg-[#090D12] border border-gray-800 flex items-center justify-between text-left text-xs">
        <div className="flex items-center space-x-2">
          {isNative ? (
            <div className="p-1 rounded bg-emerald-500/20 text-[#00FF66]">
              <ShieldCheck className="w-4 h-4" />
            </div>
          ) : (
            <div className="p-1 rounded bg-cyan-500/20 text-[#00F0FF]">
              <Smartphone className="w-4 h-4" />
            </div>
          )}

          <div>
            <div className="flex items-center space-x-1.5">
              <span className="font-gaming font-bold text-gray-200">
                {isNative ? 'Native Android VpnService Active' : 'Capacitor Android Architecture'}
              </span>
              <span className="text-[9px] font-mono-code px-1.5 rounded bg-black text-gray-400 border border-gray-800">
                com.ffvpn.app
              </span>
            </div>
            <p className="text-[10px] text-gray-500">
              {isNative
                ? 'WireGuard GoBackend kernel tunnel active'
                : 'Ready to build APK via Termux • WireGuard GoBackend ready'}
            </p>
          </div>
        </div>

        <button
          onClick={() => setShowConfig(!showConfig)}
          className="px-2 py-1 rounded bg-gray-900 hover:bg-gray-800 border border-gray-700/80 text-[11px] font-mono-code text-gray-300 flex items-center space-x-1"
        >
          <FileText className="w-3 h-3 text-[#00FF66]" />
          <span>{showConfig ? 'Hide' : 'Inspect'}</span>
        </button>
      </div>

      {/* WireGuard Config Drawer */}
      {showConfig && (
        <div className="mt-2 p-3 bg-black border border-emerald-500/40 rounded-xl text-left font-mono-code text-[10px] text-emerald-400 relative">
          <div className="flex items-center justify-between pb-1.5 mb-1.5 border-b border-gray-800">
            <span className="text-gray-400 font-bold">Generated WireGuard Native Config</span>
            <button
              onClick={handleCopy}
              className="px-2 py-0.5 rounded bg-gray-900 hover:bg-gray-800 text-gray-300 flex items-center space-x-1 text-[10px]"
            >
              {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              <span>{copied ? 'Copied' : 'Copy'}</span>
            </button>
          </div>
          <pre className="whitespace-pre overflow-x-auto leading-relaxed">{configText}</pre>
        </div>
      )}
    </div>
  );
};
