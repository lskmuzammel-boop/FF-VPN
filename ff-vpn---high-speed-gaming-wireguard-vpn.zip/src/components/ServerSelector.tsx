import React from 'react';
import { ChevronRight, Crown, Signal, Zap } from 'lucide-react';
import { Language, VpnServer } from '../types/vpn';
import { translations } from '../locales/translations';

interface ServerSelectorProps {
  server: VpnServer;
  onOpenModal: () => void;
  lang: Language;
}

export const ServerSelector: React.FC<ServerSelectorProps> = ({
  server,
  onOpenModal,
  lang,
}) => {
  const t = translations[lang];

  return (
    <div className="w-full px-4 mb-4">
      <div
        onClick={onOpenModal}
        className="w-full p-3.5 rounded-xl bg-[#0B1015] hover:bg-[#111822] border border-gray-800 hover:border-emerald-500/50 cursor-pointer transition-all duration-200 flex items-center justify-between shadow-lg shadow-black/40 group active:scale-[0.99]"
      >
        <div className="flex items-center space-x-3">
          {/* Flag & VIP Badge */}
          <div className="relative flex items-center justify-center w-11 h-11 rounded-lg bg-gray-900 border border-gray-700/80 text-2xl">
            {server.flag}
            {server.isPremium && (
              <Crown className="w-3.5 h-3.5 text-amber-400 absolute -top-1 -right-1 drop-shadow" />
            )}
          </div>

          {/* Server Info */}
          <div className="text-left">
            <div className="flex items-center space-x-2">
              <span className="font-gaming font-bold text-sm text-gray-100 group-hover:text-emerald-400 transition-colors">
                {server.name}
              </span>
              {server.isPremium ? (
                <span className="text-[10px] font-mono-code px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold">
                  VIP
                </span>
              ) : (
                <span className="text-[10px] font-mono-code px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-bold">
                  FREE
                </span>
              )}
            </div>

            <div className="flex items-center space-x-2.5 mt-0.5 text-xs text-gray-400">
              <span className="font-mono-code text-[11px] text-[#00FF66] font-semibold flex items-center gap-1">
                <Signal className="w-3 h-3" />
                {server.ping} ms
              </span>
              <span>•</span>
              <span className="text-gray-400 text-[11px]">{server.city}</span>
              <span>•</span>
              <span className="text-gray-400 text-[11px] flex items-center gap-0.5">
                <Zap className="w-3 h-3 text-cyan-400" />
                {server.load}% load
              </span>
            </div>
          </div>
        </div>

        {/* Change Server Action */}
        <div className="flex items-center space-x-1 text-gray-400 group-hover:text-[#00FF66] transition-colors">
          <span className="text-xs font-gaming font-medium hidden sm:inline">{t.changeServer}</span>
          <ChevronRight className="w-5 h-5" />
        </div>
      </div>
    </div>
  );
};
