import React, { useState } from 'react';
import { X, Crown, Copy, Check, ShieldCheck, Clock, AlertCircle, Sparkles } from 'lucide-react';
import { Language, PremiumRequest, UserProfile } from '../types/vpn';
import { translations } from '../locales/translations';
import { submitPremiumRequest, getStoredPremiumRequests } from '../services/firebase';

interface PremiumModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  onRefreshUser: () => void;
  lang: Language;
}

export const PremiumModal: React.FC<PremiumModalProps> = ({
  isOpen,
  onClose,
  user,
  onRefreshUser,
  lang,
}) => {
  const [phone, setPhone] = useState('');
  const [trxId, setTrxId] = useState('');
  const [copied, setCopied] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const t = translations[lang];

  if (!isOpen) return null;

  const BKASH_NUMBER = '01770110154';
  const myRequests = getStoredPremiumRequests().filter(
    (req) => req.userId === user.id || req.userEmail === user.email
  );

  const handleCopyNumber = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(BKASH_NUMBER);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phone || phone.trim().length < 11) {
      setNotification({
        type: 'error',
        message: lang === 'bn' ? 'সঠিক বিকাশ নাম্বার দিন (১১ ডিজিট)' : 'Please enter valid 11-digit bKash number',
      });
      return;
    }

    if (!trxId || trxId.trim().length < 6) {
      setNotification({
        type: 'error',
        message: lang === 'bn' ? 'সঠিক বিকাশ TrxID দিন' : 'Please enter valid bKash Transaction ID',
      });
      return;
    }

    setSubmitting(true);
    try {
      submitPremiumRequest({
        userId: user.id,
        userEmail: user.email,
        userName: user.displayName,
        phoneNumber: phone.trim(),
        trxId: trxId.trim(),
      });

      setNotification({
        type: 'success',
        message: t.submitSuccess,
      });
      setPhone('');
      setTrxId('');
      onRefreshUser();
    } catch {
      setNotification({
        type: 'error',
        message: 'Submission failed. Please check network.',
      });
    } finally {
      setSubmitting(false);
    }
  };

  const formatExpiry = (expiryTimestamp?: number) => {
    if (!expiryTimestamp) return '';
    return new Date(expiryTimestamp).toLocaleDateString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/85 backdrop-blur-md p-0 sm:p-4 overflow-y-auto">
      <div className="w-full max-w-lg bg-[#070B0E] border border-amber-500/40 rounded-t-2xl sm:rounded-2xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in slide-in-from-bottom-6 duration-200">
        {/* Header */}
        <div className="px-5 py-4 border-b border-amber-500/30 flex items-center justify-between bg-gradient-to-r from-amber-950/40 via-[#0B1015] to-[#070B0E]">
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-xl bg-amber-500/20 border border-amber-500/40">
              <Crown className="w-5 h-5 text-amber-400 animate-pulse" />
            </div>
            <div>
              <h2 className="font-gaming font-extrabold text-base text-amber-300 tracking-wide">
                {t.premiumTitle}
              </h2>
              <p className="text-[11px] text-gray-400">Low Ping BDIX & Esports VIP Route</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-gray-400 hover:text-white hover:bg-gray-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 overflow-y-auto space-y-5 flex-1">
          {/* Active VIP Status Banner */}
          {user.isPremium ? (
            <div className="p-4 rounded-xl bg-gradient-to-r from-emerald-950/50 to-amber-950/40 border border-emerald-500/40 text-left">
              <div className="flex items-center space-x-2 text-emerald-400 font-gaming font-bold text-sm">
                <ShieldCheck className="w-5 h-5" />
                <span>{t.approvedVip}</span>
              </div>
              <p className="text-xs text-gray-300 mt-1">
                {lang === 'bn'
                  ? `আপনার ভিআইপি মেম্বারশিপ সক্রিয় আছে। মেয়াদ শেষ হবে: ${formatExpiry(user.premiumExpiry)}`
                  : `Your VIP membership is active until ${formatExpiry(user.premiumExpiry)}`}
              </p>
            </div>
          ) : (
            /* Pricing Card */
            <div className="p-4 rounded-xl bg-gradient-to-br from-amber-950/30 via-[#0E151E] to-black border border-amber-500/30 text-left relative overflow-hidden">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[11px] font-mono-code font-bold uppercase tracking-wider text-amber-400 px-2 py-0.5 rounded bg-amber-500/10 border border-amber-500/20">
                    VIP 30 DAYS PASS
                  </span>
                  <div className="mt-2 text-3xl font-gaming font-extrabold text-white">
                    300 <span className="text-sm font-sans text-amber-400">BDT</span>
                  </div>
                </div>
                <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center">
                  <Sparkles className="w-6 h-6 text-amber-400 animate-spin-slow" />
                </div>
              </div>

              {/* VIP Benefits */}
              <div className="mt-3 grid grid-cols-2 gap-2 text-xs text-gray-300">
                <div className="flex items-center space-x-1.5">
                  <span className="text-amber-400">✓</span>
                  <span>BDIX Ultra 14ms Low Ping</span>
                </div>
                <div className="flex items-center space-x-1.5">
                  <span className="text-amber-400">✓</span>
                  <span>Free Fire & PUBG Low Jitter</span>
                </div>
                <div className="flex items-center space-x-1.5">
                  <span className="text-amber-400">✓</span>
                  <span>Dedicated VIP WireGuard Tunnels</span>
                </div>
                <div className="flex items-center space-x-1.5">
                  <span className="text-amber-400">✓</span>
                  <span>1Gbps Uncapped Speed</span>
                </div>
              </div>
            </div>
          )}

          {/* bKash Payment Instructions */}
          <div className="p-4 rounded-xl bg-[#0B1015] border border-gray-800 text-left space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-gaming font-bold text-sm text-gray-200">
                {t.paymentDetails}
              </span>
              <span className="text-xs px-2 py-0.5 rounded font-bold bg-pink-950/60 text-pink-400 border border-pink-500/30">
                bKash Personal
              </span>
            </div>

            <p className="text-xs text-gray-400 leading-relaxed">
              {lang === 'bn'
                ? 'আপনার বিকাশ অ্যাপ অথবা *247# ডায়াল করে নিচের নাম্বারে ৩০০ টাকা "Send Money" করুন। এরপর নিচে ট্রানজেকশন আইডি (TrxID) দিন।'
                : 'Send 300 BDT using bKash "Send Money" to the number below, then submit your Transaction ID (TrxID).'}
            </p>

            {/* bKash Number Box with Copy */}
            <div className="flex items-center justify-between p-3 rounded-lg bg-black border border-gray-700/80">
              <div>
                <span className="text-[10px] text-gray-500 block uppercase font-mono-code">bKash Personal Number</span>
                <span className="font-mono-code font-bold text-base text-pink-400 tracking-wider">
                  {BKASH_NUMBER}
                </span>
              </div>
              <button
                type="button"
                onClick={handleCopyNumber}
                className={`px-3 py-1.5 rounded-lg text-xs font-gaming font-bold flex items-center space-x-1.5 transition-all ${
                  copied
                    ? 'bg-emerald-500 text-black'
                    : 'bg-pink-600 hover:bg-pink-500 text-white'
                }`}
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    <span>{t.copied}</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>{t.copyNumber}</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Form to submit TrxID */}
          <form onSubmit={handleSubmit} className="p-4 rounded-xl bg-[#0B1015] border border-gray-800 space-y-3 text-left">
            <span className="font-gaming font-bold text-sm text-gray-200 block">
              {t.submitPayment}
            </span>

            {notification && (
              <div
                className={`p-3 rounded-lg text-xs flex items-center space-x-2 ${
                  notification.type === 'success'
                    ? 'bg-emerald-950/80 border border-emerald-500/40 text-emerald-300'
                    : 'bg-red-950/80 border border-red-500/40 text-red-300'
                }`}
              >
                {notification.type === 'success' ? (
                  <Check className="w-4 h-4 shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 shrink-0" />
                )}
                <span>{notification.message}</span>
              </div>
            )}

            <div>
              <label className="text-xs text-gray-400 block mb-1">{t.phoneLabel}</label>
              <input
                type="tel"
                placeholder={t.phonePlaceholder}
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3 py-2 bg-black border border-gray-800 rounded-lg text-sm text-gray-100 placeholder-gray-600 font-mono-code focus:outline-none focus:border-pink-500"
                required
              />
            </div>

            <div>
              <label className="text-xs text-gray-400 block mb-1">{t.trxIdLabel}</label>
              <input
                type="text"
                placeholder={t.trxPlaceholder}
                value={trxId}
                onChange={(e) => setTrxId(e.target.value.toUpperCase())}
                className="w-full px-3 py-2 bg-black border border-gray-800 rounded-lg text-sm text-gray-100 placeholder-gray-600 font-mono-code uppercase focus:outline-none focus:border-pink-500"
                required
              />
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-2.5 rounded-lg bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-500 hover:to-rose-500 text-white font-gaming font-bold text-sm shadow-lg shadow-pink-600/30 active:scale-[0.99] transition-all cursor-pointer"
            >
              {submitting ? 'Submitting...' : t.submitPayment}
            </button>
          </form>

          {/* User's Payment Submissions History */}
          {myRequests.length > 0 && (
            <div className="space-y-2 text-left">
              <span className="text-xs font-gaming font-bold text-gray-400 uppercase tracking-wide">
                {t.paymentHistory}
              </span>
              <div className="space-y-1.5">
                {myRequests.map((req) => (
                  <div
                    key={req.id}
                    className="p-3 rounded-lg bg-[#0B1015] border border-gray-800 flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-mono-code font-bold text-gray-200">
                          {req.trxId}
                        </span>
                        <span className="text-gray-500 font-mono-code">({req.phoneNumber})</span>
                      </div>
                      <span className="text-[10px] text-gray-500">
                        {new Date(req.createdAt).toLocaleString()}
                      </span>
                    </div>

                    <div className="flex items-center space-x-1.5">
                      {req.status === 'approved' ? (
                        <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-500/40 font-bold text-[10px] flex items-center gap-1">
                          <Check className="w-3 h-3" />
                          {t.approvedVip}
                        </span>
                      ) : req.status === 'rejected' ? (
                        <span className="px-2 py-0.5 rounded bg-red-950 text-red-400 border border-red-500/40 font-bold text-[10px] flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          {t.rejectedVip}
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-500/40 font-bold text-[10px] flex items-center gap-1 animate-pulse">
                          <Clock className="w-3 h-3" />
                          {t.pendingVerification}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
